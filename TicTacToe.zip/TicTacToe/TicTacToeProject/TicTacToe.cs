﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MidtermRiyadAlsabagh
{
    public partial class TicTacToe : Form
    {

        //when true it is player X, when false it is plyaer O
        //since we have two players, boolean is the most optimal variable to determine turn
        bool playerTurn = true;

        public TicTacToe()
        {
            InitializeComponent();
        }

        //we set every button to call this method when clicked
        //it is possible to make 9 methods for each button and repeat the code, but that would be against programming protocol
        private void button_clicked(object sender, EventArgs e){
            
            //This basically gives us the button we clicked
            Button buttonClicked = (Button)sender;

            //if it is true, player X if false then player O
            if (playerTurn)
                buttonClicked.Text = "X";
            else
                buttonClicked.Text = "O";

            //this will change the turn of the player everytime we click it
            if (playerTurn == true){
                playerTurn = false;
            }
            else{
                playerTurn = true;
            }

            //this is what we are going to use to disable the button so it cannot be clicked again
            buttonClicked.Enabled = false;

            weHaveAWinner();
        }

        //this method will tell us if we have a winner by comparing button text
        private void weHaveAWinner(){

            string player = "";

            if(playerTurn == false){
                player = "Player 1";
            }
            else {
                player = "Player 2";
            }

            //essentially, when three button have the same text, we will change their text to a line and declare a winner
            //we make the code display the winner message box only if three are connected
            //a message box will display and then when clicked "Ok", the program will close
            if (b1.Text == b2.Text && b2.Text == b3.Text && b1.Text != ""){
                if (MessageBox.Show(player + " won the game!", "Winner Screen", MessageBoxButtons.OK) == DialogResult.OK){
                    System.Windows.Forms.Application.Exit();
                }
            }
            else if (b4.Text == b5.Text && b5.Text == b6.Text && b4.Text != "")
            {
                if (MessageBox.Show(player + " won the game!", "Winner Screen", MessageBoxButtons.OK) == DialogResult.OK){
                    System.Windows.Forms.Application.Exit();
                }
            }
            else if (b7.Text == b8.Text && b8.Text == b9.Text && b7.Text != "")
            {
                if (MessageBox.Show(player + " won the game!", "Winner Screen", MessageBoxButtons.OK) == DialogResult.OK){
                    System.Windows.Forms.Application.Exit();
                }
            }
            else if (b1.Text == b4.Text && b4.Text == b7.Text && b1.Text != "")
            {
                if (MessageBox.Show(player + " won the game!", "Winner Screen", MessageBoxButtons.OK) == DialogResult.OK){
                    System.Windows.Forms.Application.Exit();
                }
            }
            else if (b2.Text == b5.Text && b5.Text == b8.Text && b2.Text != "")
            {
                if (MessageBox.Show(player + " won the game!", "Winner Screen", MessageBoxButtons.OK) == DialogResult.OK){
                    System.Windows.Forms.Application.Exit();
                }
            }
            else if (b3.Text == b6.Text && b6.Text == b9.Text && b3.Text != "")
            {
                if (MessageBox.Show(player + " won the game!", "Winner Screen", MessageBoxButtons.OK) == DialogResult.OK){
                    System.Windows.Forms.Application.Exit();
                }
            }
            else if (b1.Text == b5.Text && b5.Text == b9.Text && b1.Text != "")
            {
                if (MessageBox.Show(player + " won the game!", "Winner Screen", MessageBoxButtons.OK) == DialogResult.OK){
                    System.Windows.Forms.Application.Exit();
                }
            }
            else if (b3.Text == b5.Text && b5.Text == b7.Text && b3.Text != "")
            {
                if (MessageBox.Show(player + " won the game!", "Winner Screen", MessageBoxButtons.OK) == DialogResult.OK){
                    System.Windows.Forms.Application.Exit();
                }
            }

        }
    }
}
